---
title: "Notes"
book: "radiance"
---
