---
date: 2025-05-12T18:19:06+05:30
title: "IP Addressing Techniques"
tags: ["IP Addressing", "CIDR", "Subnetting", "Supernetting", "IP Techniques"]
series: "Network Layer"
categories: ["Digital Communication and Computer Networks"]
draft: false
---

### 🚀 IP Addressing Techniques

IP addressing techniques are essential for efficiently allocating and managing network addresses. These techniques help network administrators organize address spaces, divide networks, and enable the smooth routing of data packets.



---

#### 1. **Classful Addressing**

* **Classful Addressing** divides the IPv4 address space into five distinct classes: **A**, **B**, **C**, **D**, and **E**.

  * **Class A**: `0.0.0.0` to `127.255.255.255` – Suitable for large networks with many hosts.
  * **Class B**: `128.0.0.0` to `191.255.255.255` – Medium-sized networks.
  * **Class C**: `192.0.0.0` to `223.255.255.255` – Small networks.
  * **Class D**: `224.0.0.0` to `239.255.255.255` – Used for **multicast** communication.
  * **Class E**: `240.0.0.0` to `255.255.255.255` – Reserved for **future use** and experimental purposes.

  **How to Calculate the Class of an IP Address**:

  * Look at the **first octet** (the first number before the first dot in the IP address).
  * Convert the first octet to **binary** and check the leading bits:

    * **Class A**: First bit is `0` → Range: `0`–`127`
    * **Class B**: Starts with `10` → Range: `128`–`191`
    * **Class C**: Starts with `110` → Range: `192`–`223`
    * **Class D**: Starts with `1110` → Range: `224`–`239`
    * **Class E**: Starts with `1111` → Range: `240`–`255`

  **Example**:

  * IP address: `192.168.1.1`
  * First octet: `192`
  * Binary: `11000000` → Starts with `110`, so it belongs to **Class C**.

---


#### 2. **Classless Inter-Domain Routing (CIDR)**

**CIDR** is a more flexible method of allocating IP addresses than classful addressing. CIDR allows for **variable-length subnet masks**, making it more efficient and scalable.

- **CIDR Notation**: An IP address is written in **slash notation**, where the number after the slash indicates the length of the network prefix (e.g., `192.168.1.0/24`).
- **Network Prefix**: The part of the address that identifies the network.
- **Host Portion**: The remaining part of the address used to identify individual devices.

**CIDR Example**: 
- `192.168.1.0/24` means the first 24 bits are the network portion, and the remaining 8 bits are used for hosts.

---
#### 3. **Subnetting**

**Subnetting** involves dividing a larger IP network into smaller **subnets**. This helps optimize address allocation, increases security, and improves routing efficiency.

- **Subnet Mask**: A 32-bit mask that separates the **network** portion from the **host** portion of an IP address.

- **Subnetting Example**:  
  Given the network `192.168.1.0/24`, if you want to create **4 subnets**, you would use `255.255.255.192` as the subnet mask, resulting in the following subnets:
  - `192.168.1.0/26`
  - `192.168.1.64/26`
  - `192.168.1.128/26`
  - `192.168.1.192/26`

---

##### **Subnet Calculation**

To create **N subnets**, calculate the number of bits (**n**) needed using the formula:

```
N ≤ 2^n
```

→ Take the smallest `n` such that this condition is satisfied.

Then, modify the default subnet mask by **borrowing `n` bits** from the host portion.

```
New Subnet Mask = Default Subnet Mask + n bits
```

---

##### **Number of Hosts per Subnet**

To calculate how many hosts can exist in each subnet:

```
Hosts per Subnet = 2^(number of host bits remaining) - 2
```

> (We subtract 2 to account for the **Network ID** and **Broadcast Address**)

---

##### **Example: Create 6 subnets from a Class C network**

- **Given**: `192.168.10.0/24`
- **Default Mask (Class C)**: `255.255.255.0`
- **Goal**: 6 subnets

###### Step 1: Find the number of bits needed
```
6 ≤ 2^n  →  n = 3 (since 2^3 = 8 ≥ 6)
```

###### Step 2: Calculate the new subnet mask
```
Default Mask: 255.255.255.0 → Borrow 3 bits
New Subnet Mask: 255.255.255.224 (i.e., /27)
```

###### Step 3: Calculate hosts per subnet
```
Remaining host bits = 8 - 3 = 5
Hosts/Subnet = 2^5 - 2 = 30 hosts
```

---

##### **Result:**
With a `/27` subnet mask:
- **Total Subnets**: 2^3 = 8
- **Hosts per Subnet**: 30
- **Subnet Blocks**:
  - `192.168.10.0/27`
  - `192.168.10.32/27`
  - `192.168.10.64/27`
  - `192.168.10.96/27`
  - `192.168.10.128/27`
  - `192.168.10.160/27`
  - `192.168.10.192/27`
  - `192.168.10.224/27`


---

#### 4. Supernetting

Supernetting is the reverse of subnetting. Instead of dividing a network into smaller subnets, 
you combine several **contiguous** smaller networks into a **larger block** (supernet) 
to reduce routing overhead—commonly used in **route aggregation**.

**When to use Supernetting**:
- All networks must be contiguous (sequential).
- All networks must have the same prefix length.
- The number of networks must be a power of 2.

--------------------------------------------------------
**How to Calculate a Supernet**:
1. Convert the network addresses to binary.
2. Identify the **common prefix** shared by all addresses.
3. The number of common bits becomes the **new subnet mask** (prefix).
4. The new address is the first address with that prefix.

--------------------------------------------------------
**Example**:
You want to combine these Class C networks:
- 192.168.1.0/24
- 192.168.2.0/24
- 192.168.3.0/24

Step 1: Binary of first octets:
- 192.168.1.0 → 11000000.10101000.00000001.00000000
- 192.168.2.0 → 11000000.10101000.00000010.00000000
- 192.168.3.0 → 11000000.10101000.00000011.00000000

Step 2: Find common prefix:
- Common up to 22 bits → New prefix: /22

Step 3: New supernet address:
- 192.168.0.0/22

--------------------------------------------------------
**Result**:
192.168.0.0/22 includes:
- 192.168.0.0
- 192.168.1.0
- 192.168.2.0
- 192.168.3.0

**Benefits**:
- Reduces routing table entries.
- Efficient IP address management.

---

#### 5. **Private and Public IP Addresses**

- **Public IP Addresses**: These are globally unique and routable on the internet. Public IPs are assigned to devices that need direct internet access (e.g., servers, gateways).
  
    **Example**: `8.8.8.8` (Google DNS).

- **Private IP Addresses**: These are used within local networks and cannot be routed on the internet. They are part of reserved address spaces specified by RFC 1918.
  
    **Private IP Ranges**:
    - Class A: `10.0.0.0` to `10.255.255.255`
    - Class B: `172.16.0.0` to `172.31.255.255`
    - Class C: `192.168.0.0` to `192.168.255.255`

---

### 🧠 Deep Insights

- **CIDR and Subnetting** have significantly improved IP address allocation by allowing finer control over how address spaces are divided and used.
- While **private IP addresses** help in **address conservation**, **NAT (Network Address Translation)** allows multiple devices in a private network to share a single public IP.
- **Supernetting** has become important for **ISPs** to manage large address spaces more efficiently, especially in the context of **IPv6**.

---

### 🧭 Key Takeaways

- **CIDR** is a more efficient way of allocating IP addresses compared to classful addressing.
- **Subnetting** and **supernetting** are critical techniques for managing and optimizing network addresses.
- **Private and public IP addresses** play an essential role in network segmentation and internet connectivity.

---

### 🔗 Links
- Previous: [Internet Protocol (IP)]({{< relref "internet-protocol-ip.md" >}})
- Next: [Network-Layer Protocols]({{< relref "network-layer-protocols.md" >}})

